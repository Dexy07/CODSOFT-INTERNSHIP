You want to clear your whole GTA V directory from mods and don't know which files you need to delete?
This tool helps you to detect all mod files and folders and gives you the chance to delete all mods.

_________ CONTENTS _________ 

1. System Requirement 
2. Information 
3. How to use 
4. FAQ 
5. Known Bugs 
6. Credits
7. Changelog 

_________ System Requirement _________ 
--- Microsoft .NET Framework 4.8 

_________ Information _________ 
This Tool show all mod files and folders. 

Tested for GTA Online!
No Guarantee or Support for Pirated Versions of GTA5!!! 

_________ How to use _________ 
1. Start this Tool 
2. Look which files / folders you need to delete manually or
3. Click on "Delete all mods" and this delete all installed mod files and folders :)

_________ FAQ _________ 
--- What do this Tool exactly? 
This tool shows you all your installed mods (files and folders)

--- Are there more planned features? 
Not yet. But I'm working to equip this tool with many features as possible.

_________ Known Bugs _________ 
No Bugs or Errors for now.

_________ Credits _________ 
- Gang1111 (Developer)

_________ Changelog _________ 
- 1.0
Initial Release

1.1
- [Added] Context Menu (right mouse click menu) with some extras for Detected Mod list
- [Added] Whitelist (Copy selected mods in your documents (for now))
- [Added] Tool Status on buttom left of the tool
- [Added] "Show whitelist window on start" to Settings
- [Added] Possiblity to change the Whitelist folder/path
- [Added] Mod List Details (Name and Path separately)
- [Improved] Mod List view
- [Improved] Filter
- [Removed] Maximaze tool button
- [Removed] Minimaze tool button

1.2
- [Added] Windows code (to work with some windows functions like File/Folder Properties or Copy progress)
- [Added] Detailed File/Folder Size check to the list view
- [Added] "Show File Properties" to ContextMenu (Right click menu on list) [Window File/Folder Properties window]
- [Added] Alternative copy method for Folders whose size is GB [Window Copy progress window]
- [Fix] Folder size check (Not displaying correctly when sub folders are exist)
- [Fix] Crash on first start
- [Improved] File/Folder Size check
- [Removed] Double Click actions

1.3
- [Added] File/Folder deletion after copy
- [Added] "Refresh list" button (Modlist and whitelist)
- [Added] "Do not delete file/folder after copy" checkbox
- [Added] Show/Hide whitelist option to menu
- [Added] Save checkstate "Do not delete file/folder after copy" in settings file
- [Added] Item counter to Modlist and whitelist (It counts how many Files/Folder are detected)
- [Added] Window Animation to Show/Hide whitelist
- [Added] "Animated Show/Hide Whitelist" option to menu
- [Fix] Copy file/folder from whitelist to gta v folder doesn't show the file/folder in mod list
- [Fix] Possible crash fix that occurred when "Open whitelist folder" was clicked but the tool crashed if folder doesnt exist
- [Improved] Whitelist & Modlist window (combined both in same window)
- [Improved] Some interface elements
- [Improved] "Delete all Mods from GTA V folder" button (added red color to button)
- [Removed] Change whitelist path change (Fixed to GTA 5 folder>>GTA V Mod Remove Tool)
- [Removed] Tab control (when you press tab on your keyboard)
- [Removed] Whitelist window
- [Removed] Some Whitelist settings and functions
- [Removed] Possiblity to resize List window

1.4
- [Added] "current path" to Settings
- [Added] Text area to Settings to show current path
- [Added] Possibility to change the path
- [Fix] Steam file detection

1.5
- [Added] Support for the new Rockstar Launcher
- [Added] Suppoer for missing file/folder that was added by the R*L
- [Improved] Whitelist Folder (moved from gta path to one folder upper) [Default folder name: "Rockstar Games"]
- [Removed] Unnecessary and unused code
- [Removed] Possibility to change the path manually

1.6
- [Fix] "Delete all unnecessary files and folder from GTA V folder" not working correctly after selecting another path
- [Fix] "Select a path" is not saving and loading correctly
- [Improved] Some code under the hood

1.7
- [Added] "Support" to Menu
- [Added] "Support Ticket" to Support (Email Support)
- [Added] "Discord" to Support (Live Support)
- [Added] Copy all files/folders to whitelist button (" >> ")
- [Added] Copy all files/folders from whitelist to GTA V folder button (" << ")
- [Improved] Tool loading time
- [Improved] Some tool window elements (UI)
- [Improved] Delete mods button

2.0
- [Added] Support for Epic Games launcher
- [Added] "Delete this file / folder" to contextmenu (right click on the item)
- [Added] Animations speed to "Settings"
- [Fix] Tool size on startup when "show whitelist" is enabled
- [Fix] Automatic path detection on tool start
- [Fix] Tool closing when pressing "Cancel" on "Select new path" dialog
- [Improved] Tool UI
- [Improved] "Animate windows size / whitelist"
- [Removed] The weird unvisible but clickable UI element
- [Removed] "Support" Menu

2.1
- [Added] Automatically starting with administrator rights
- [Fix] Some issues
- [Improved] For the LS Tuners update
- [Removed] Delete files/folder from GTA V folder after copy

2.2
- [Added] Seperate whitelist window
- [Fix] Some issues (that occur with the latest windows updates) [Thx to C0D3z0 for his bug report]
- [Improved] File copy system (now copy only with the windows copy shell/window)
- [Improved] Some Tool interface elements
- [Removed] Whitelist animation (and all animation options)

2.2.1
- [Added] "Slow Mode" for more stability
- [Fix] "Error 1" bug (Hopefully)

2.2.2
- [Fix] A bug where whitelist copy progress not working when the game installed on root of the hard drive
- [Improved] Copy progress (Its now moving instead of copying. This way works faster)
- [Improved] Slow Mode

2.3.0
- [Added] Custom Whitelist folder support
- [Added] "Settings" -> "Select new whitelist path"
- [Added] Some helpfull text
- [Improved] .NET Framework from 4.5 to 4.8
- [Improved] Context Menu to lists (Game & Whitelist) [You can right click on some files for more options]
- [Improved] Window style (Now resizable window - but restricted)
- [Improved] Whitelist UI
- [Removed] "Move "selected file / folder" to whitelist" button from main & whitelist window (moved to context menu)
- [Removed] Slow Mode

I hope this update will fix the windows 11 only desktop bug.
Its not a bug in windows 11. It was a bug in .Net Framework.

2.3.1
- [Added] Added message to whitelist directory changing (Because it doesnt move any files and folder from the old to the new directory)
- [Fix] Whitelist (Moving the files & folders to the wrong folder after changing the default directory)
- [Fix] Crash issues (While open whitelist folder if it doesn't exist)

2.3.2
- [Added] "refresh list" to Context menu [right click on list] (now it show "refresh list" instead of unselectable options)
- [Fix] Whitelist folder creation (it still creates the default folder even though a custom folder was selected)

2.3.3
- [Fix] File management (It disable the the "Read Only" on the folder on tool startup)

2.4.0
- [Added] Folder explorer [BETA] (You can load files & folders inside a selected folder)
- [Added] "Check MD5 Hash" to right click menu (Soon i will expand this to detect modded RPF files and showing them as modified)
- [Temporary Disabled] Move single file to whitelist
- [Removed] Some unnecessary filters from selection

2.4.1
- [Added] "Support" section to menu (Contains all recommended support links)
- [Added] "Show filter list" [BETA] to menu (shows filtered files & folders from the game)
- [Added] Filter list: Folder explorer [BETA] (You can show files & folders inside a selected folder)
- [Added] Filter list: "Check MD5 for all showed files" [BETA] (to scan MD5 hash for all showed files) [Tool will freeze while scanning! (Further improvements soon)]
- [Added] Filter list: "Check MD5 Hash" to right click menu (for single file check)
- [Improved] MD5 Hash algorithm (Soon i will expand this to detect modded RPF files and showing them as modified)
- [Removed] MD5 hash check from main window (Because its not needed for mods)
- [Removed] Folder explorer from main window (Because of its critical bugs. Reverted to old double click function.)

2.4.2
- [Improved] Changed "Delete all mods from GTA V folder" button color to darker one
- [Improved] Changed visible file color from red to blue
- [Improved] Renamed "Filter list" to "Game files"
- [Improved] Renamed and removed "Show" text in "Whitelist" & "Game files" in menu
- [Improved] Highlighted text in "Whitelist" & "Game files" in menu
- [Improved] "mods" folder will highlighted in orange and on deletion it will ask again to delete this folder
- [Soon] Next update will contains bunch of improvements and fixes. Mainly for "Game files" and MD5 hash checks!

2.4.3 [Hotfix to 2.4.2]
- [Fix] "mods" does not move to whitelist

2.4.4
- [Added] All game files that was added on update v3028
- [Soon] Next big Tool (2.5.0) update will contains bunch of improvements and fixes. Mainly for "Game files" and MD5 hash checks!

2.4.5
- [Added] All game files that was added on update v3095